#!/bin/bash
source /var/bitstew/lib/uaa_path_lib
yes | cp -r qa.assets.zip /tmp/qa.assets.zip
while [ "$1" != "" ]; do
  case $1 in
    -o|--overwrite)
    overwrite=$2
    ;;
  esac
shift
done
if [[ -z ${overwrite} ]]; then
  overwrite="true"
fi
retrieve_response=$(uaacurl -XGET "https://localhost:18443/director-services/SystemServices/main?system:runTemplate=plugins/applicationdistribution/com.ge.ad.retrieve/retrieve_application_service.xml&path=/tmp/qa.assets.zip&mode=disk")
echo "${retrieve_response}"
if [[ "${retrieve_response}" == *"FAILURE"* ]]; then
  echo Not able to retrieve application
  exit 1
else
  VERSION=$(echo ${retrieve_response} | grep -oP 'version="\K[^"]+')
  install_response=$(uaacurl -XGET "https://localhost/director/SystemServices/main?system:runTemplate=plugins/applicationdistribution/com.ge.ad.install/install_application_node_execution.xml&URN=qa.assets&Version=${VERSION}&overwrite=${overwrite}")
  echo "${install_response}"
  if [[ "${install_response}" == *"FAILURE"* ]]; then
      echo Not able to intall application
      exit 1
  fi
fi
